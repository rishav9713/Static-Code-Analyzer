import os
import sqlite3
import pymysql
import hashlib
import base64
import requests
import jwt

# 1. Hardcoded Credentials
db_user = "admin"
db_password = "password123"
db_host = "localhost"

# 2. Debug Mode Enabled
DEBUG = True  # Vulnerable configuration for debug mode in production

# 3. Path Traversal Vulnerability
file_path = input("Enter the filename to open: ")
with open(file_path, "r") as f:
    print(f.read())

# 4. Insecure Use of eval()
user_input = input("Enter something to evaluate: ")
eval(user_input)  # Potential remote code execution vulnerability

# 5. Exposing Server Information
print("Server running on 192.168.0.1")  # Exposing internal server information

# 6. Missing Input Validation
user_age = input("Enter your age: ")  # No validation for user input
print(f"User age: {user_age}")

# 7. Authentication Flaws (Hardcoded Auth)
def authenticate_user(username, password):
    if username == "admin" and password == "admin_pass":  # Hardcoded auth credentials
        return True
    return False

# 8. Data Encryption Issues (Plaintext Storage)
user_data = {
    "name": "Alice",
    "credit_card": "4111111111111111"  # Sensitive data stored as plaintext
}

# 9. Poor Exception Handling (Generic Exceptions)
try:
    result = 1 / 0
except Exception as e:
    print("An error occurred:", e)  # Generic exception handling

# 10. Dependency Management Issues (Vulnerable Library)
# This example simulates using an outdated or insecure library function
response = requests.get("http://example.com")  # Not validated for SSL

# 11. API Usage Vulnerabilities
api_key = "abcd1234"
response = requests.get(f"http://api.example.com/data?api_key={api_key}")  # Hardcoded API key

# 12. CSRF Protection Missing
def process_payment(request):
    if request.get("is_valid"):
        # Missing CSRF token verification
        print("Processing payment...")

# 13. Insecure Server-Side Code Execution
def run_code(user_code):
    exec(user_code)  # Insecure server-side execution

# 14. Business Logic Errors
def apply_discount(price, discount):
    if discount > price:
        print("Discount applied!")  # Business logic error (discount > price)

apply_discount(50, 60)  # Should be handled but isn't

# 15. Poor Code Quality (Dead Code and Hardcoded Magic Values)
DEBUG = True
PI = 3.14159  # Magic value
if DEBUG:
    print("This is debug mode!")  # Debug code left in production

# 16. Insecure Cryptography Practices
hashed_password = hashlib.md5("mypassword".encode()).hexdigest()  # MD5 is insecure

# JWT without proper signature validation
encoded_jwt = jwt.encode({"user_id": "123"}, "insecure_secret", algorithm="HS256")
decoded_jwt = jwt.decode(encoded_jwt, "insecure_secret", algorithms=["HS256"])
